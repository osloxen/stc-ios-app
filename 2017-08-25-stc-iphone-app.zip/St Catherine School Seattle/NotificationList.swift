//
//  NotificationList.swift
//  Muninn
//
//  Created by David Berge on 11/8/15.
//  Copyright © 2015 Joe Dog Productions. All rights reserved.
//

import UIKit
import TwitterKit

//class NotificationList: UITableViewController {
class NotificationList: UITableViewController {

    
    //TODO:  I don't know what this class is or what it does.  I think I can delete it.  Need to experiment with that.
    

    func getTweetsTesting() {
        super.viewDidLoad()
        
    }
    
}
