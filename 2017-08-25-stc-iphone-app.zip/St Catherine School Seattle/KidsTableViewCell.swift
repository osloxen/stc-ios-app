//
//  KidsTableViewCell.swift
//  Muninn
//
//  Created by David Berge on 11/24/15.
//  Copyright © 2015 Joe Dog Productions. All rights reserved.
//

import UIKit

class KidsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var kidName: UILabel!
    @IBOutlet weak var kidPicture: UIImageView!
    

    override func layoutSubviews() {
        
    }

    
    
    

}
