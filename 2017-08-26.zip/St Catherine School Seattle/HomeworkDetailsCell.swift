//
//  HomeworkDetailsCell.swift
//  St Catherine School Seattle
//
//  Created by David Berge on 5/5/17.
//  Copyright © 2017 Joe Dog Productions. All rights reserved.
//

import UIKit

class HomeworkDetailsCell: UITableViewCell {

    @IBOutlet weak var adTitle: UILabel!
    @IBOutlet weak var adText: UILabel!
    @IBOutlet weak var homeworkDetail: UILabel!
    
    
}
