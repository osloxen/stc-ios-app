//
//  StaffTableViewCell.swift
//  Muninn
//
//  Created by David Berge on 12/22/15.
//  Copyright © 2015 Joe Dog Productions. All rights reserved.
//

import UIKit

class StaffTableViewCell: UITableViewCell {
    

    @IBOutlet weak var staffName: UILabel!

    @IBOutlet weak var staffTitle: UILabel!
    
    @IBOutlet weak var lastName: UILabel!
}
